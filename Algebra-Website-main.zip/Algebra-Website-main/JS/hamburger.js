
var navigation = document.querySelector(".nav-bar")
var hamburgerMenu = document.querySelector(".hamburger")

//On click activate display class
hamburgerMenu.addEventListener("click",()=>{navigation.classList.toggle("DISPLAY");
    hamburgerMenu.classList.toggle("DISPLAY")})